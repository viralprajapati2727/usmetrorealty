<?php
defined('_JEXEC') or die('Restricted access');
require(JPATH_COMPONENT.'/views/property/tmpl/default_noresult.php');
?>