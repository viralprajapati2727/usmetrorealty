<?php
defined('_JEXEC') or die('Restricted access');
require(JPATH_COMPONENT.'/views/companyproperties/tmpl/default_company.php');
?>