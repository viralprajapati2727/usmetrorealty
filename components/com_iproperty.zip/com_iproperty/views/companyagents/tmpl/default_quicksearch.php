<?php
defined('_JEXEC') or die('Restricted access');
require(JPATH_COMPONENT.'/views/advsearch/tmpl/default_agentsearch.php');
?>


