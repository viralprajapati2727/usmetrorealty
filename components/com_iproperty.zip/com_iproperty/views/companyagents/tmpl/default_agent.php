<?php
defined('_JEXEC') or die('Restricted access');
require(JPATH_COMPONENT.'/views/agentproperties/tmpl/default_agent.php');
?>


