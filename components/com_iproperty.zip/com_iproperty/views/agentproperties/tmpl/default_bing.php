<?php
defined('_JEXEC') or die('Restricted access');
require(JPATH_COMPONENT.'/views/allproperties/tmpl/default_bing.php');
?>