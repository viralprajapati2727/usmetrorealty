<?php
/**
 * @version 3.0 2012-12-04
 * @package Joomla
 * @subpackage Intellectual Property
 * @copyright (C) 2009 - 2015 the Thinkery LLC. All rights reserved.
 * @license GNU/GPL see LICENSE.php
 */

defined( '_JEXEC' ) or die( 'Restricted access');
$this->document->addScript(JURI::root(true).'/components/com_iproperty/assets/advsearch/dropdowns.js');
?>
<div id="mapDropdowns" class=""></div>
