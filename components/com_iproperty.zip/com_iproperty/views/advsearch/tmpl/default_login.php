<?php
defined('_JEXEC') or die('Restricted access');
require(JPATH_COMPONENT.'/views/ipuser/tmpl/default_login.php');
?>
