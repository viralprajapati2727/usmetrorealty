CREATE TABLE IF NOT EXISTS #__extrawatch_visit2goal (
	visitId int not null,
	goalId int not null,
	timestamp int not null
);