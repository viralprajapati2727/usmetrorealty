ALTER TABLE `#__extrawatch` ADD `city` VARCHAR( 255 ) NULL DEFAULT NULL;
ALTER TABLE `#__extrawatch` ADD `latitude` FLOAT NULL DEFAULT NULL; 
ALTER TABLE `#__extrawatch` ADD `longitude` FLOAT NULL DEFAULT NULL;
 
