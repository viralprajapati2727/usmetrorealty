DROP TABLE `#__extrawatch_ip2c`;
