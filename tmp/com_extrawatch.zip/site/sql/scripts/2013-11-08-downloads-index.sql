ALTER TABLE  `#__extrawatch_dm_counter` ADD INDEX (  `did` );
ALTER TABLE  `#__extrawatch_dm_counter` ADD INDEX (  `ddate` );
ALTER TABLE  `#__extrawatch_dm_counter` ADD INDEX (  `referrerId` );
