ALTER TABLE  `#__extrawatch_blocked` ADD UNIQUE (`ip`);
