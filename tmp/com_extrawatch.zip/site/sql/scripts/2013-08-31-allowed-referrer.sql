ALTER TABLE  `#__extrawatch_dm_paths` ADD  `allowedReferrer` varchar(255) DEFAULT NULL;
