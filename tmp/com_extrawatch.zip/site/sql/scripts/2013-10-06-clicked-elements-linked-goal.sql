CREATE INDEX clicked_element_xpath_condition_idx ON `#__extrawatch_goals` (`clicked_element_xpath_condition`);


