UPDATE `#__extrawatch` set inactive = 1 where inactive is NULL;
