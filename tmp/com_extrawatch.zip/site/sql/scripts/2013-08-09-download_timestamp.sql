ALTER TABLE  `#__extrawatch_dm_counter` ADD  `timestamp` int DEFAULT NULL;
