ALTER TABLE #__extrawatch_dm_counter add column userId varchar(255);
