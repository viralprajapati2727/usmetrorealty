ALTER TABLE  `#__extrawatch_goals` ADD  `send_email` varchar(3) DEFAULT NULL;


