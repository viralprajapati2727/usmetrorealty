ALTER TABLE  `#__extrawatch_project` ADD  `lastPayment` int DEFAULT NULL;
ALTER TABLE  `#__extrawatch_project` ADD  `lastLogin` int DEFAULT NULL;
ALTER TABLE  `#__extrawatch_project` ADD  `timeOfActivation` int DEFAULT NULL;


