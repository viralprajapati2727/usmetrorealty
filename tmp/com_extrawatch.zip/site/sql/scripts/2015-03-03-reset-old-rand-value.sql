DELETE FROM `#__extrawatch_config` where `name` = 'rand' limit 1
