ALTER TABLE `#__extrawatch_history` ADD `city` VARCHAR( 255 ) NULL DEFAULT NULL;
ALTER TABLE `#__extrawatch_history` ADD `latitude` FLOAT NULL DEFAULT NULL; 
ALTER TABLE `#__extrawatch_history` ADD `longitude` FLOAT NULL DEFAULT NULL;
 
