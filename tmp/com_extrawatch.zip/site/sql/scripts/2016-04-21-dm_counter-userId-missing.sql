ALTER TABLE `#__extrawatch_dm_counter` add userId INT(11);
