ALTER TABLE  `#__extrawatch_goals` MODIFY `clicked_element_xpath_condition` VARCHAR( 2048 )` int DEFAULT NULL;


