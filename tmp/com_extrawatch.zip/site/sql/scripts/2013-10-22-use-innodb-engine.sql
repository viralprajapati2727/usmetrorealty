ALTER TABLE #__extrawatch ENGINE=InnoDB;
ALTER TABLE #__extrawatch_history ENGINE=InnoDB;
ALTER TABLE #__extrawatch_uri ENGINE=InnoDB;
ALTER TABLE #__extrawatch_uri_history ENGINE=InnoDB;