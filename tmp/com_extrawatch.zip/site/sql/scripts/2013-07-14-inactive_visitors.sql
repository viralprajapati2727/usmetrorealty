ALTER TABLE  `#__extrawatch` ADD  `inactive` INT(1) DEFAULT 1;
ALTER TABLE  `#__extrawatch_history` ADD  `inactive` INT(1) DEFAULT 1;
