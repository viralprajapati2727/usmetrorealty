ALTER TABLE  `#__extrawatch_dm_counter` ADD  `ip` varchar(255) DEFAULT NULL;

