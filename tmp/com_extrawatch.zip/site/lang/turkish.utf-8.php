<?php


/**
 * @file
 * ExtraWatch - A real-time ajax monitor and live stats  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
 * @package ExtraWatch  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
 * @version @VERSION@  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
 * @revision @REVISION@  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
 * @license http://www.gnu.org/licenses/gpl-3.0.txt     GNU General Public License v3  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
 * @copyright (C) @YEAR@ by CodeGravity.com - All rights reserved!  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
 * @website http://www.codegravity.com  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
 */

defined('_JEXEC') or die('Restricted access');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

//ExtraWatch language file - to create a new language file, just copy the english.php to Örnek german.php and place into./components/com_extrawatch/lang/  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Main Menu.
DEFINE('_EW_MENU_STATS', "İstatistikler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_GOALS', "Hedefler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_SETTINGS', "Ayarlar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_CREDITS', "Yapımcılar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_FAQ', "SSS");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_DOCUMENTATION', "Dökümantasyon");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_LICENSE', "Lisans");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_DONATORS', "Bağış Yapanlar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_SUPPORT', "Joomla Watch'u Destekle ve Yönetim Panelindeki Reklamları Kaldır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Left visitors real-time window.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISITS_VISITORS', "Son Ziyaretçiler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISITS_BOTS', "Botlar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISITS_CAME_FROM', "Geldigi Yer");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISITS_MODULE_NOT_PUBLISHED', "ExtraWatch modülü henüz yayinda olmadığı için herhangi bir istatistik verisi bulunmamaktadır. Lütfen modülü kurup yayınlayınız.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISITS_PANE_LOADING', "Ziyaretler Yükleniyor...");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Right stats window.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_TITLE', "Haftalık Ziyaret İstatistikleri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_WEEK', "hafta");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_THIS_WEEK', "bu hafta");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_UNIQUE', "tekil");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_LOADS', "görüntüleme");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_HITS', "hitler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_TODAY', "bugün");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_FOR', "için");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_ALL_TIME', "Tüm zamanlar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_EXPAND', "genişlet");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_COLLAPSE', "Portatif");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_URI', "Sayfalar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_COUNTRY', "Ülkeler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_COUNTRIES', "Ülkeler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_USERS', "Kullanıcılar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_REFERERS', "Referanslar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_IP', "IPler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_BROWSER', "Tarayıcılar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_OS', "OS");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_KEYWORDS', "Anahtar Kelimeler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_GOALS', "Hedefler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_TOTAL', "Toplam");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_DAILY', "Günlük");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_DAILY_TITLE', "Günlük İstatistikler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_ALL_TIME_TITLE', "Tüm zamanlarin istatistikleri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_LOADING', "yükleniyor...");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_LOADING_WAIT', "yükleniyor... lütfen bekleyiniz.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_IP_BLOCKING_TITLE', "IP Engelleme");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_IP_BLOCKING_ENTER', "Elle IP Girisi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_IP_BLOCKING_MANUALLY', "Engellemek istediginiz IP numarasini girin. (örnek: 217.242.11.54, arama kriterlerini içeren tüm IPleri engellemek için; 217.* veya 217.242.*)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_IP_BLOCKING_TOGGLE', "Gerçekten engellemek istiyor musun ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_PANE_LOADING', "İstatistikler yükleniyor...");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Settings.
DEFINE('_EW_SETTINGS_TITLE', "Ayarlar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_DEFAULT', "Varsayılan");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_SAVE', "Kaydet");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_APPEARANCE', "Görünüm");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_FRONTEND', "Ön Uç");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_HISTORY_PERFORMANCE', "Geçmiş  &amp; Performans");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_ADVANCED', "Gelişmiş");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_IGNORE', "Yoksay");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_BLOCKING', "Engelle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_EXPERT', "Uzman");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_RESET_CONFIRM', "Tüm istatistik kayıtlarını gerçekten silmek istiyor musun?");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_RESET_ALL', "Tümünü Sil");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_RESET_ALL_LINK', "Tüm istatistikleri &amp; ziyaretçi bilgisini sil");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_LANGUAGE', "Dil");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_SAVED', "Ayarlar kaydedildi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_ADD_YOUR_IP', "Kendi IP numarani ekle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_TO_THE_LIST', "listeye");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Other / mostly general.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TITLE', "Gerçek zamanlı AJAX Joomla ekranı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_BACK', "Geri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ACCESS_DENIED', "Bu içeriği görme izinin yok!");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_LICENSE_AGREE', "Sözleşmeyi okudum ve kabul ediyorum &amp; sözleşme yukarıda");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_LICENSE_CONTINUE', "Devam et");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SUCCESS', "İşlem başarılı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_RESET_SUCCESS', "Tüm istatistik verileri ve ziyaretçi bilgileri başarıyla silindi.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_RESET_ERROR', "Veri tamamen silinemedi bir hata var.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_CREDITS_TITLE', "Yapımcılar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TRENDS_DAILY_WEEKLY', "Günlük ve haftalık istatistikleri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_AJAX_PERMISSION_DENIED_1', "AJAX kabul edilmedi: Bu istatistiklere joomlanın configuration.php dosyasında belirlenen adresten erişebilirsiniz. ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_AJAX_PERMISSION_DENIED_2', "Belki de alan adınızın önüne www. eklemeyi unuttunuz. Javascriptiniz ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_AJAX_PERMISSION_DENIED_3', "dosyasına");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_AJAX_PERMISSION_DENIED_4', "alan adının farklı olduğunu düşünmesine sebep olan adresinden erişmeyi deniyor.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Header.
DEFINE('_EW_HEADER_DOWNLOAD', "Son eklenti kodunu al");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HEADER_CAST_YOUR', "Bize");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HEADER_VOTE', "oy ver");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Tooltips.
DEFINE('_EW_TOOLTIP_CLICK', "İpuçlarini görmek için tıkla");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_MOUSE_OVER', "Tooltipi göstermek için fareyi üstüne getir");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_YESTERDAY_INCREASE', "dünkü artış");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_HELP', "Harici online yardım dökümanını aç");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_WINDOW_CLOSE', "Pencereyi kapat");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_PRINT', "Çıktı al");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Goals.
DEFINE('_EW_GOALS_INSERT', "Yeni hedef gir");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_UPDATE', "Hedef numarasını değiştir.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_ACTION', "Eylem");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_TITLE', "Yeni Hedef");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_NEW', "Yeni Hedef");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_RELOAD', "Tekrar Yükle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_ADVANCED', "Gelişmiş");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_NAME', "İsim");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_ID', "Kimlik");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_URI_CONDITION', "URL Durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_GET_VAR', "Alma");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_GET_CONDITION', "Alma Durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_POST_VAR', "Gönderme");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_POST_CONDITION', "Gönderme Durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_TITLE_CONDITION', "Başlık Durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_USERNAME_CONDITION', "Kullanıcı Durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_IP_CONDITION', "IP Durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_CAME_FROM_CONDITION', "Gelen Kaynak Durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_BLOCK', "Engelleme");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_REDIRECT', "Yönlendirilen URL");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_HITS', "Hitler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_ENABLED', "Aktif");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_EDIT', "Düzenle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_DELETE', "Sil");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_DELETE_CONFIRM', "Bu hedef için tüm istatistikler silinecek. Gerçekten silmek istiyor musun?");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Frontend.
DEFINE('_EW_FRONTEND_COUNTRIES', "Ülkeler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS', "Ziyaretçiler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_TODAY', "Bugün");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_YESTERDAY', "Dün");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_THIS_WEEK', "Bu Hafta");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_LAST_WEEK', "Geçen Hafta");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_THIS_MONTH', "Bu Ay");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_LAST_MONTH', "Geçen Ay");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_TOTAL', "Toplam");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

// Settings description - quite long.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_DEBUG', "ExtraWatch hata ayıklama modunda. Bu şekilde hatanın nedenini bulabilirsiniz. Kapatmak için, /components/com_extrawatch/config.php dosyasında EXTRAWATCH_DEBUG değerini 1 yerine 0 yapın");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_STATS_MAX_ROWS', "İstatistikler genişletilmiş moda alındığında azami kaç satır gösterileceği.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_STATS_IP_HITS', "Önceki günlerde, girilen değerden daha az hite sahip olan tüm IP adresleri, IP geçmişinden silinecek.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_STATS_URL_HITS', "Önceki günlerde, girilen değerden daha az hite sahip olan tüm URLler, IP geçmişinden silinecek.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_IGNORE_IP', "Belirli IPleri istatistiklerin dışında tut. Yeni bir satır ile ayır. Burada arama kriterleri kullanılabilir. <br/>Örnek: 192.* girmek, 192.168.51.31, 192.168.16.2, gibi adresleri yoksayacaktır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_UPDATE_TIME_VISITS', "Ziyaretçinin milisaniye cinsinden yenileme süresi, lütfen dikkatli kullanınız (öntanımlı süre 2000). Ardından ExtraWatch arka ucunu yeniden yükleyiniz.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_UPDATE_TIME_STATS', "İstatistiklerin milisaniye cinsinden yenileme süresi, lütfen dikkatli kullanınız (öntanımlı süre 4000). Ardından ExtraWatch arka ucunu yeniden yükleyiniz.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_MAXID_BOTS', "Veritabanında tutulacak bot ziyaret kaydı sayısı.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_MAXID_VISITORS', "Veritabanında tutulacak gerçek ziyaret sayısı.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_LIMIT_BOTS', "Arka uçta görüntülenecek olan bot sayısı.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_LIMIT_VISITORS', "Arka uçta görüntülenecek olan gerçek ziyaretçi sayısı.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_TRUNCATE_VISITS', "Uzun başlık ve URLlerde gösterilecek azami karakter sayısı.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_TRUNCATE_STATS', "İstatistik panelinde gösterilecek azami karakter sayısı.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_STATS_KEEP_DAYS', "Veritabanında istatistiklerin kaç gün tutulacağı, 0 = sonsuz.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_TIMEZONE_OFFSET', "Suncudan farklı bir saat diliminde bulunduğunuzda. (saat olarak artı veya eksi değer)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_WEEK_OFFSET', "Hafta düzenlemesi, zaman damgası/(3600*24*7) 1.1.1970 tarihinden itibaren hafta numarası verir, bu düzenleme haftanın pazartesi günü ile başlamasını sağlar ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_DAY_OFFSET', "Gün düzenlemesi, zaman damgası/(3600*24) 1.1.1970 tarihinden itibaren gün numarası verir, bu düzenleme günün 00:00'da başlamasını sağlar ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_HIDE_LOGO', "<b>(PRO sürümde çalışır)</b> Ön uçta 1x1px boş simge kullanmayı sağlar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_IP_STATS', "IP adresi istatistiklerini etkinleştirir. Bazı ülkelerde IP adresini veritabanında uzun süre tutmak yasalara aykırıdır. Kullanımda sorumluluk size aittir.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_HIDE_ADS', "Bu ayar, sizi rahatsız etmeleri durumunda arka uçtaki reklamları gizler. Reklamların orada kalmasını sağlayarak bu aracın gelişmesine katkıda bulunmuş olursunuz. Teşekkürler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_TOOLTIP_ONCLICK', "Araç bilgisinin fareye tıklamak yerine, üzerine geldiğinde görüntülenmesini istiyorsanız işareti kaldırın.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_SERVER_URI_KEY', "Öntanımlı olan 'REDIRECT_URL'dir, url yeniden yazma özelliğini kullanıyorsanız bu zaten standarttır. Eğer sadece index.php'nin kayıtları tutuluyorsa, 'SCRIPT_URL' olarak değiştirilebilir.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_BLOCKING_MESSAGE', "Engellenen kullanıcıya gösterilen veya kullanıcıların neden engellendiğine dair detaylı bilgi mesajı.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_TOOLTIP_WIDTH', "Araç bilgisi genişliği");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_TOOLTIP_HEIGHT', "Araç bilgisi yüksekliği");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_TOOLTIP_URL', "Ziyaretçinin IPsini görselleştirmek için, buraya herhangi bir URL girebilirsiniz. {ip} kullanıcının IPsi ile değiştirilecektir. Örnek: http://somewebsite.com/query?iplookup={ip}");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_IGNORE_URI', "İstatistiklerin yoksaymasını istediğiniz adresleri yazabilirsiniz. Kriterler kullanabilirsiniz (* ve ?). Örnek: /freel?n* ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_NAME', "Buraya bir hedef ismi girin. Bu isim istatistiklerde görünecek.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_URI_CONDITION', "Alan adınızın ardından gelen herşey. http://www.codegravity.com/projects/ adresi için URI: /projects/ (Örnek: <b>/projects*</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_GET_VAR', "GET değişkeni, URLde genelde ? veya &amp; işaretleri ardından görebileceğiniz bir değişkendir. Örnek: http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Aynı zamanda <u>*</u> bu alandaki tüm get değerlerini tarayabilirsiniz. (Örnek: <b>n*me</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_GET_CONDITION', "Burada bir önceki alandan alınan değeri sağlayan bir değer girmelisiniz. (Örnek: <b>p?t*r</b>) ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_POST_VAR', "Benzer şekilde, formlardan gelen değerleri de kontrol ediyoruz. Sitenizde form varsa, şu şekilde bir alana sahiptir  &lt;input type='text' name='<u>experiences</u>' /&gt; ve burada da arama kriterlerini kullanabilirsiniz.. (Örnek: <b>exper*ces</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_POST_CONDITION', "POST alanından değer için bir eşleşme. Örnek: Eğer kullanıcıların java tecrübesi olup olmadığını kontrol etmek istersek, <b>*java*</b>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_TITLE_CONDITION', "Eşleşmesi gereken sayfanın başlığı. (Örnek: <b>*serbest çalışan programcılar*</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_USERNAME_CONDITION', "Giriş yapmış olan kullanıcının adı. (örnek: <b>ahmetyılmaz*</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_IP_CONDITION', "Kullanıcının geldiği IP adresi: (Örnek: <b>201.9?.*.*</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_CAME_FROM_CONDITION', "Kullanıcının geldiği adres. (Örnek: <b>*www.google.*</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_REDIRECT', "Kullanıcı, tarafınızdan belirlenen bir adrese yönlendirildi. 'Engelleme'den daha yüksek önceliği vardır: (Örnek: <b>http://www.codegravity.com/goaway.html</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_TRUNCATE_GOALS', "Hedef tablosunda kaç adet karakterin eksiltileceği");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_NO_BACKLINK', "<b>(PRO sürümde çalışır)</b> codegravity.com adresine olan bağlantıyı kaldırabilirsiniz, ancak bunu yapmazsanız mutluluk duyarız. Teşekkürler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_COUNTRIES', "Ön uçta ülkelerin toplam istatistiklerini görüntüle. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_ süresi ayarlandıktan sonra ön uçta etkin olacaktır. ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_COUNTRIES_FIRST', "Eğer ön uçta Ziyaretçi/Ülke sıralamasını değiştirmek istiyorsanız işareti kaldırın, Ziyaretçiler daha önce görünecektir.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_COUNTRIES_NUM', "Ön uçta gösterilmesini istediğiniz ülke sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS', "Ön uçta ülkelerden gelen ziyaretçileri göster. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_ süresi ayarlandıktan sonra ön uçta etkin olacaktır. ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_CACHE_FRONTEND_COUNTRIES', "Ön uçtaki tüm ülke verilerinin önbelleğe alınması için saniye cinsinden geçen süre");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_CACHE_FRONTEND_VISITORS', "Ön uçtaki tüm ziyaretçi verilerinin önbelleğe alınması için saniye cinsinden geçen süre");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS_TODAY', "Bugünkü ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS_YESTERDAY', "Dünkü ziyaretçilerin ön uçta gösterilmesi.. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Bu haftaki ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Geçen haftaki ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Bu ayki ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Geçen ayki ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS_TOTAL', "ExtraWatch yüklemesinden bu yana toplam ziyaretçi sayısını göster. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_LANGUAGE', "Kullanılacak dil dosyasıları /components/com_extrawatch/lang/ adresinde bulunur. Eğer yeni bir dil dosyası oluşturmak isterseniz, öncelikle projenin anasayfasını kontrol edin, eğer orada bulamazsanız, english dosyasını örneğin german.php ismi ile buraya kopyalayın. Ardından, sağda anahtar değerleri tercüme edebilirsiniz.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS', "Hedefler özel parametreler belirtmenize olanak sağlar. Bu parametreler eşleştiğinde, hedef sayacı yükselir. Bu şekilde kullanıcının belirli bir adresi ziyaret edip etmediğini, girilen belirli bir değeri, belirli bir kullanıcı adını, ya da belirli bir adresten gelenleri takip edebilirsiniz. Aynı zamanda bu kullanıcıları engelleyebilir, ya da onları başka bir adrese yönlendirebilirsiniz.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_INSERT', "İsim haricindeki tüm alanlarda arama kriterleri * ve ? kullanabilirsiniz. Örnek: ?itap (eşleşenler: kitap, bitap, ..),  o*r (eşleşenler: or, onur, otur ..) ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_BLOCK', "Ziyaretçinin engellenmesini istiyorsanız değeri 1 yapın. İçeriğin geri kalanı yerine sadece engellendiği mesajını görecektir. Bir yönlendirme yapılmayacak ve IP adresi 'engellenenler'in istatistiklerine eklenecektir. (Örnek kullanım: <b>1</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

/* new translations */  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_COUNTRY_CONDITION', "Ülke durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_COUNTRY_INVERSED', "Ülke tersine durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_COUNTRY_CONDITION', "Büyük harflerle 2 harfli ülke kodu (Örnek: <b>TH</b>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_INTERNAL', "Dahili");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_FROM', "Başlangıç");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_TO', "Bitiş");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_ADD_TO_GOALS', "Hedeflere ekle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISITS_ADD_GOAL_COUNTRY', "Bu ülke için bir hedef ekle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_REPORT_BUG', "Hata ya da özellik rapor et");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_COUNTRY', "Ülke");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


/* translations 1.2.8b_12 */  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_COUNTRIES_UPPERCASE', "Eğer ön uçta ülke isimlerinin büyük harflerle görünmesini isterseniz(Örnek: Almanya, İngiltere yerine ALMANYA, İNGİLTERE)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_CACHE_FRONTEND_USERS', "Ön uçtaki kullanıcıların verilerinin önbelleğe alınması için saniye cinsinden geçen süre");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Toplam:'da gösterilecek başlangıç değerleri (ön uçta). Başka bir istatistik aracından geçiş yaptığınızda kullanışlı bir araçtır. (Örnek: 20000). Bu özelliği kullanmak istemiyorsanız değeri tekrar 0 yapın.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_IGNORE_USER', "Bu kutuda listelenen kullanıcıları yoksay. Satır başına sadece bir adet girilmelidir. (Örnek: kendim {line break} murat_*) ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_USERS_MOST', "Günün en aktif kullanıcıları, toplam kullanıcı:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_SPAMWORD_BANS_ENABLED', "Aşağıdaki spam listesinde belirtilen kelimeler için engellemeyi etkinleştirir");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_SPAMWORD_LIST', "Spam botları tarafından en sık kullanılan kelimeler. Burada ? ve * kriterleri kullanılabilir, (Örnek: ph?rmac*). Eğer yukarıdaki seçenek aktif ise, ExtraWatch saldırganın web sitenize (HTTP POST isteği) bu spam kelimeleri içeren bir form gönderip göndermediğini kontrol edecektir. (Sadece form Joomla tabanlı bir websitesi yüklediğinde geçerlidir. (forum ve yorumlar için de geçerli) Buna rağmen, mümkün olan her formu göndermeye çalışan spam botlarını engellemekte oldukça etkilidir.)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_ANTI_SPAM', "Anti-Spam");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_USER_LINK', "Ön uç Kullanıcılar modülünde bir adres belirterek kullanıcının kullanıcı adına tıkladığında açılmasını sağlayan bağlantı. {user} dizgisini içermelidir, bu dizginin yerini kullanıcı adı alacaktır. (Örnek: index.php?option=com_comprofiler&task=userProfile&user={user}) ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

/* translations 1.2.11b */  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_KEYPHRASE', "Anahtar sözcükler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_HISTORY_MAX_VALUES', "Geçmiş sekmesinde olabilecek en yüksek değer (Örnek: <i>100</i>)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_DESC_ONLY_LAST_URI', "Ziyaretlerde, ziyaret edilen tüm sayfalar yerine sadece son sayfayı göster");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_HIDE_REPETITIVE_TITLE', "Ziyaretlerde, ziyaret edilen sayfa başlığında tekrar eden site ismini gizle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_HISTORY_MAX_DB_RECORDS', "Ziyaret Geçmişi'nde, veritabanında tutulacak en yüksek ziyaret sayısı. Lütfen bu ayara dikkat edin, eğer trafiğiniz yüksekse, oldukça hızlı bir şekilde büyüyebilir. Durum kısmında geçmiş tablosunun ne kadar veri tuttuğunu düzenli olarak kontrol edin.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_UNINSTALL_KEEP_DATA', "<span style='color:red'>Backup your DB tables first if using this option!</span>Kaldırma yaparken, Veritabanı Tabloları'nı tut. Sürüm yükseltme yapıyor ve verilerinizi saklamak istiyorsanız, kaldırma yapmadan önce bu seçeneği işaretleyin.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

/* email reports */
DEFINE('_EW_DESC_EMAIL_REPORTS_ENABLED', "Sabah okumak üzere, bir önceki günün raporlarını eposta ile geceden teslim alırsınız.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_REPORTS_ADDRESS', "Raporları almak istediğiniz eposta adresi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Eposta raporlarında sadece {value} değerindazami olan satırları dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: 5)</i>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Eposta raporlarına sadece günlük değişim yüzde {value} değerinin üzerinde olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: 5)</i>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Eposta raporlarına sadece günlük değişim yüzde {value} değerinin altında olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: -10)</i>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Eposta raporlarına sadece yedi günlük değişim yüzde {value} değerinin üzerinde olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: 2)</i>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Eposta raporlarına sadece yedi günlük değişim yüzde {value} değerinin altında olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: -13)</i>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Eposta raporlarına sadece otuz günlük değişim yüzde {value} değerinin üzerinde olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: 2)</i>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Eposta raporlarına sadece otuz günlük değişim yüzde {value} değerinin altında olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: -13)</i>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_DESC_FRONTEND_NOFOLLOW', "<b>(PRO sürümde çalışır)</b> Eğer logo bağlantısının rel='nofollow' özelliğine sahip olmasını istiyorsanız bu ayarı etkinleştirin. ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_NAME_TRUNCATE', "Eposta satır isminde yer alacak olan azami karakter sayısı. Eğer eposta uygulamanızdaki mesaj penceresi çok küçük olması durumunda değiştirebilirsiniz.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_MENU_HISTORY', "Geçmiş");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_EMAILS', "Epostalar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_STATUS', "Veritabanı Durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_BLOCKED', "Bu IPler anti-spam tarafından engellendi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


DEFINE('_EW_HISTORY_VISITORS', "Ziyaretçi Geçmişi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HISTORY_SHOWING_ONLY', "Sadece son %d kayıt gösteriliyor.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                Bu değeri değiştirmek için, Ayarlar -&gt; Geçmiş &amp; Performans -&gt; HISTORY_MAX_DB_RECORDS yolunu izleyin. Dikkatli olun, bu ayar aşağıdaki verinin yüklenme süresine etki edektir.  ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_BUG', "Hata Raporu Gönder");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_FEATURE', "Yeni Özellik İste");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_VISITS_CAME_FROM_KEYWORDS', "Anahtar Kelimeler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_BLOCKING_UNBLOCK', "engeli kaldır");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_KEYPHRASE ', "Anahtar kelime");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_STATUS_DATABASE_TABLE_NAME', "tablo adı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATUS_DATABASE_ROWS', "satırlar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATUS_DATABASE_DATA', "veri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATUS_DATABASE_TOTAL', "toplam");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_EMAIL_REPORTS', "Eposta Raporları");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EMAIL_REPORT_GENERATED', "Dün oluşturulmuş, filtrelenmiş eposta raporu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EMAIL_REPORTS_VALUE_FILTERS', "Eposta Değer Filtreleri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EMAIL_REPORTS_VALUE', "değer");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EMAIL_REPORTS_PERCENT', "yüzde");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EMAIL_REPORTS_1DAY_CHANGE', "1 günlük değişim");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EMAIL_REPORTS_7DAY_CHANGE', "7 günlük değişim");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EMAIL_REPORTS_28DAY_CHANGE', "28 günlük değişim");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ANTISPAM_BLOCKED', "ExtraWatch bugün %d spamci girişini engelledi, Toplam: %d");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ANTISPAM_ADDRESSES', "Engellenen IP Adresi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ANTISPAM_SETTINGS', "Anti-Spam Ayarları");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TRAFFIC_AJAX', "AJAX trafik güncellemeleri (haritalar hariç)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


DEFINE('_EW_HISTORY_PREVIOUS', "önceki");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HISTORY_NEXT', "sonraki");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

/** additional translation for 1.2.11 for countries in more rows */  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS', "Ülke kolonu sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_COUNTRIES_MAX_ROWS', "Ülke satırı sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_COUNTRIES_NAMES', "Ülke isimlerini göster/gösterme");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST', "Önce bayrakları, ardından yüzdeyi göster");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

/* ExtraWatch 1.2.14 translations */  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_GOALS_GET_INVERSED', "Tersine durumu al");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_POST_INVERSED', "Tersine durumu gönder");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_TITLE_INVERSED', "Başlığın tersine durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_USERNAME_INVERSED', "Kullanıcı adının tersine durumu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_CAME_FROM_INVERSED', "Tersine durumdan gelmiş");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_STATS_MAP', "Son Ziyaret Haritası");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_MAP_ENTER_KEY', "Lütfen, son ziyaret haritasını görüntülemek için <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> anahtarını girin:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_MAP_STORE_KEY', "depo anahtarı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_MAP_INVALID_KEY', "Lütfen, <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> adresinden aldığınız ipinfodb anahtarını girin");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_SIZEQUERY_BAD_REQUEST', "Hatalı İstek: ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_VISIT_SUBMITED_FIELDS', "Gönderilen form alanları:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISIT_URL_PARAMETERS', "URL parametreleri:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISIT_ADD_PAGE', " Sayfayı hedef olarak ekle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISIT_BLOCK_IP', " IP Adresini Engelle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISIT_SUBMITED_FROM_VARIABLE', " Eklenen form değişkenini hedef olarak ekle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISIT_URL_PARAMETER_GOAL', " bu adresi hedef olarak ekle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_TREND_EMPTY', "Boş");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_NOT_NUMBER', " UYARI: Girdiğiniz değer bir sayı değil. ExtraWatch düzgün çalışmayacak!");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EVALUATION_LEFT', "&nbsp; Bu 15 günlük Deneme Sürümü. <b>%d</b> gününüz kaldı. Bu adresten <a href='http://www.codegravity.com/donate/extrawatch/' target='_blank'>Alan adınız için ExtraWatch lisansı</a> bu ve sonraki sürümler için, hayat boyu kullanım hakkını alabilirsiniz.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TRIAL_VERSION_EXPIRED', " Deneme sürümünüz sona erdi. Lütfen, ExtraWatch'u satın alın.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_CONFIG_LICENSE_ACTIVATED', "Lisans başarıyla etkinleştirildi, teşekkürler.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_CONFIG_LICENCE_DONT_MATCH', "<b>Hata: lisans anahtarı ve alan adınız eşleşmedi.</b><br/>Etkinleştirmek için aşağıdaki formda girdiğiniz adresi girdiyseniz, lütfen info@codegravity.com adresinden bizimle iletişime geçin.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_VIEW_ADMINBODY_LONG_MESSAGE', "Eğer bu mesajı yukarıda uzun bir süredir görüyorsanız, yayındaki site adresiniz hatalı olabilir.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                    components/com_extrawatch/config.php dosyasını açın  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                    yorumu kaldırın ve yayındaki site adresinizi girin Örnek:  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                    define('EXTRAWATCH_LIVE_SITE', 'http://www.codegravity.com');");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_ADMINBODY_LIVE_SITE', "Uyarı: Tarayıcınızdaki site adresi ve ayarlardaki yayındaki site adresiniz; %s ve %s eşleşmiyor.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINBODY_SET_LIVE_SITE', "Yayındaki site adresini: %s olarak ayarla ve devam et...");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_ADMINHEADER_JW', "ExtraWatch");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINHEADER_REMOVE_BACKLINK', "Bağlantıyı Kaldır");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINHEADER_KNOWLEDGE_BASE', "Bilgi Merkezi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINHEADER_FLOW', "Akış");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINHEADER_GRAPHS', "Grafikler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINHEADER_COMPONENTS', "Bileşenler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINHEADER_REVIEW', "yaz");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINHEADER_WRITE', "İnceleme ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_FLOW_TRAFFIC', "Trafik Akışı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FLOW_SELECT_PAGE', "Sayfa seç:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FLOW_OUTG_LINKS', "Listelenecek olan dış bağlantı sayısı:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FLOW_NESTING', "Yuvalama seviyesi:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FLOW_SCALE', "Ölçü:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_COMERCIAL_AD_FREE', "Reklamsız sürüm");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_COMERCIAL_THANK_DONATION', "Bağışınız için teşekkür ederiz!");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_COMERCIAL_REGISTRATION_KEY', "Alan adınız %s için kayıt anahtarı: ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_COMERCIAL_BACKLINKS_REMOVE', "Artık ön uçtaki ExtraWatch logosunu Ayarlar'dan kaldırabilir ya da saklayabilirsiniz ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


DEFINE('_EW_SIZES_LAST_CHECK', "Son kontrol zamanı:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZES_ADMINISTRATOR', "MAVİ = /administrator directory içerisindeki component/module bölümünün boyutu");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_SIZECOMPONENTS_COMPONENT', "Bileşen");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZECOMPONENTS_TOTAL', "Toplam:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZECOMPONENTS_SIZE', "Boyut");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZECOMPONENTS_REFRESH_ALL', "Tümünü Yenile");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_SIZEDATABASE_TABLE', "Tablo");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEDATABASE_SIZE', "Boyut");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEDATABASE_1DAY', "1 günlük değişim");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEDATABASE_7DAY', "7 günlük değişim");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEDATABASE_28DAY', "28 günlük değişim");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEDATABASE_NO_DATA', "veri yok");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEDATABASE_TOTAL', "Toplam:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_SIZEMODULES_REFRESH_ALL', "Tümünü Yenile");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEMODULES_TOTAL', "Toplam:");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEMODULES_MODULE', "Modül");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEMODULES_SIZE', "Boyut");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_SIZES_FILES', "Dosyalar &amp; Dizinler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZES_BYTES', "byte");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZES_KB', "KB");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZES_MB', "MB");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZES_GB', "GB");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZES_REFRESH', "Yenile");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_STATS_FOOTER', "ExtraWatch &copy;2006-%s  CodeGravity.com");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_STATUS_MB', "MB");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATUS_DATABASE', "Veritabanı Tablo Boyutları");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


DEFINE('_EW_DESC_IPINFODB_KEY', "Son ziyaret haritası ipinfodb.com anahtarı: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SETTINGS_FORCE_TIMEZONE_OFFSET', "Saat Dilimi ayarını zorunlu kıl");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


/* ExtraWatch 1.2.17 translations */  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_UPDATE', "Güncelle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_UPDATE_TITLE', "Yedekle & Sürüm yükselt");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ADMINHEADER_NA_IN_THIS_VERSION', "Ücretsiz sürümde mevcut değil, lütfen lisans sekmesini kontrol ediniz");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SPAMWORD_BANS_ENABLED', "Spam Kelimeler için engellemeyi etkinleştir");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SPAMWORD_LIST', "Spam Kelime Listesi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HIDE_REPETITIVE_TITLE', "Tekrar Eden Başlığı Gizle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TRUNCATE_VISITS', "Ziyaret gösterimini kısalt");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TRUNCATE_STATS', "İstatistiklerin gösterimini kısalt");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TRUNCATE_GOALS', "Hedeflerin gösterimini kısalt");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_LIMIT_BOTS', "Botların gösterimini kısalt");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_LIMIT_VISITORS', "Ziyaretçileri sınırla");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_WIDTH', "Tooltip Genişliği");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_HEIGHT', "Tooltip Yüksekliği");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_URL', "Tooltip Adresi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_TOOLTIP_ONCLICK', "Tooltip Tıklayarak Açılsın");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_IP_STATS', "IP istatistikleri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_IPINFODB_KEY', "IP Bilgisi Veritabanı anahtarı ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ONLY_LAST_URI', "Sadece son URL ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_FRONTEND_HIDE_LOGO', "Ön uçtaki logoyu gizle ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_NOFOLLOW', "Ön uca 'no follow' özelliği ekle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_NO_BACKLINK', "Ön uçtaki bağlantıyı kaldır");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_USER_LINK', "Ön taraftaki kullanıcı bağlantıları");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_COUNTRIES_FIRST', "Ön uçta ilk önce ülkeleri dikkate al");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_COUNTRIES_NAMES', "Ön uçta ülkelerin isimleri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_COUNTRIES_UPPERCASE', "Ön uçta ülkeleri büyük harfle göster");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Ön uçta önce ülkelerin bayraklarını göster ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_COUNTRIES_NUM', "Ön uçtaki ülke sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Ön uçta ülkelerin en yüksek sütun sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_COUNTRIES_MAX_ROWS', "Ön uçta ülkelerin en yüksek satır sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS_TODAY', "Bugün ön ucu ziyaret edenler ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS_YESTERDAY', "Dün ön ucu ziyaret edenler ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS_THIS_WEEK', "Bu hafta ön ucu ziyaret edenler ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS_LAST_WEEK', "Geçen hafta ön ucu ziyaret edenler ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_FRONTEND_VISITORS_THIS_MONTH', "Bu ay ön ucu ziyaret edenler ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS_LAST_MONTH', "Geçen ay ön ucu ziyaret edenler");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS_TOTAL', "Tüm ön uç ziyaretlerini göster");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Ön uç başlangıç toplamı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HISTORY_MAX_VALUES', "Geçmiş için en yüksek değer");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HISTORY_MAX_DB_RECORDS', "Geçmiş için azami kayıt sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_UPDATE_TIME_VISITS', "Ziyaret sürelerini güncelle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_UPDATE_TIME_STATS', "Süre istatistiklerini güncelle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_MAX_ROWS', "İstatistikler için azami satır sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_IP_HITS', "IP hitlerinin istatistikleri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MAXID_BOTS', "Azami bot kimliği sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MAXID_VISITORS', "Azami ziyaretçi kimliği sayısı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_STATS_KEEP_DAYS', "İstatistiklerin tutulacağı gün sayısı ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_CACHE_FRONTEND_COUNTRIES', "Ön uçtaki ülkeleri önbelleğe al ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_CACHE_FRONTEND_VISITORS', "Ön uçtaki ziyaretçileri önbelleğe al ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_UNINSTALL_KEEP_DATA	', "Kaldırmada veriyi sakla ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_IGNORE_IP', "IPyi yoksay");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_IGNORE_URI', "Adresi yoksay");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_IGNORE_USER', "Kullanıcıyı yoksay");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_BLOCKING_MESSAGE', "Mesaj engelleniyor");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SERVER_URI_KEY', "Sunucu URL anahtarı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_FRONTEND_VISITORS_TOTAL_INITIAL', "Ön uçtaki ziyaretçilerin başlangıç toplamı");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SIZEDATABASE_RECORDS', "Kayıtlar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
/***********EDITs*****************/  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ANTISPAM_BLOCKING_TEXT', " Engellemeyi etkili bir şekilde yapmak isterseniz, ExtraWatch ajanını tüm içerik ve formdan önce paylaşmalısınız. Örnek: temanızın sol tarafı.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                    <br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                    Modül Yöneticisi'ne gidin -> ExtraWatch ajanı -> pozisyonu sol olarak seçin");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_EMAIL_SEO_REPORTS', "SEO Raporları");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_EMAIL_SEO_REPORTS_ENABLED', "Gecelik SEO eposta raporu aktifleştirildi");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_WATCH_INSTALLATION_DEMO', "Yükleme demosunu izle");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

/** JW 1.2.18 */
DEFINE('_EW_ADMINHEADER_HEATMAP', "Heatmap");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HEATMAP_CLICKS', "clicks");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HEATMAP_TITLE', "title");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HEATMAP_CLICK_OPEN', "Click to open heatmap");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_NO_DATA', "This section contains no data yet ...");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_POSITION', "Search result num.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_BLOCKING_REASON', 'reason');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_BLOCKING_UNAUTHORIZED_ACCESS', 'Unauthorized Access');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_BLOCKING_BLOCKED_MANUALLY', 'Blocked manually');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_BLOCKING_BAD_WORD', "bad word");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HEATMAP_OF', "of");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_URI', "uri");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_COUNT', "count");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_REPORT_FOR', "SEO report for");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_MOST_DYNAMIC_KEYPHRASES', "Most dynamic keyphrases");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_MIN_POSITION', "min position");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_AVG_POSITION', "average position");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_MAX_POSITION', "max position");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_CHANGE', "change");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_DATE_OF_LAST_CHANGE', "date of last change");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_TOTAL_VISITS_FROM_SEARCH_ENGINES', "Total visits by keyphrase from search engines");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOAL_ADD_SUBMITTED_VALUE', "Add submitted variable as goal");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_RENDERED_IN', "Rendered in");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_SEO_RENDER_ONLY_CHANGED', "Render only values which were already used in previous days (have some percentage in change column)");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_REPORT_SETTINGS', "SEO Report Settings");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


DEFINE('_EW_HTTP500_ERROR', "Could not initialize ExtraWatch javascript functions! Browser could not load: \\n%s, because it returned HTTP 500 internal server error.  \\nThis usually of security restrictions by other components/plugins. Please check your .htaccess file in your root Joomla directory.  \\nIf you use Akeeba Admin tools, you need to go \ 'Akeeba htaccess maker\ ' -> \ 'Server Protection\ ' -> \ 'Exceptions\ ' -> \ 'Allow direct access to these files\ ', and add: \\n/components/com_joomlawatch/block.php \\n/components/com_joomlawatch/img.php \\n/components/com_joomlawatch/last.php \\n/components/com_joomlawatch/lastvisit.php \\n/components/com_joomlawatch/sizequery.php \\n/components/com_joomlawatch/sizequerytotal.php \\n/components/com_joomlawatch/stats.php \\n/components/com_joomlawatch/timezone.php \\n/components/com_joomlawatch/tooltip.php \\n/components/com_joomlawatch/trendtooltip.php \\n/components/com_joomlawatch/vars.php \\n/components/com_joomlawatch/visits.php \\n/components/com_joomlawatch/js/joomlawatch.js.php \\n/components/com_joomlawatch/js/maps.js.php ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_AGENT_NOT_PUBLISHED_ERROR_JOOMLA',"Warning: No visits are currently being recorded. Your ExtraWatch Agent module is published, but most probably in position which does not exist in your template.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                <br/><br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                To fix this: <br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                1. go to Modules section -&gt; ExtraWatch Agent <br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                2. change the Position to 'left' or 'footer' (or some other position).<br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                3. check if new visits are being recorded  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                <br/><br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                If this won't help, you can also: <br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                1. set 'Show Title' to 'Yes' in  Modules section -&gt; ExtraWatch Agent <br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                2. try to use some other positions of ExtraWatch agent module<br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                3. save<br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                4. after reload of your main page look for 'ExtraWatch Agent' text.<br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                5. this way you'll make sure the Agent module is published.<br/>  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                6. after that you can set 'Show Title' back to 'No'.  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
                ");
/** Goals/Import IP */  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS', "Goals");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_IMPORT', "Import goals");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_IMPORT_XML', "Import XML");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_EXPORT', "Export goals");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_FILENAME', "Select goals previously exported as XML");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ANTISPAM_IMPORT_CSV', "import anti-spam ip csv");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_AGENT_NOT_PUBLISHED_ERROR_WORDPRESS',"Warning: No visits are being recorded. You must go to Appearance->Widgets section, <br/>find ExtraWatchAgent widget and drag&drop it to some of the containers on the right side. <br/>You can publish also other ExtraWatch modules this way. <br/><br/>Check the demonstration video:<br/><br/><video autoplay='autoplay' loop='loop' controls='controls' width='1024' height='768' id='0'><source src='https://www.extrawatch.com/video/wordpress-agent-activation.webm' type='video/webm' /><source src='https://www.extrawatch.com/video/wordpress-agent-activation.mp4' type='video/mp4' /><noscript>Enable scripts to see demo video.</noscript></video><br/><br/>In case of any questions about installation or problems, you can take advantage of our support on <a href='http://www.extrawatch.com' target='_blank'>http://www.extrawatch.com</a>");



/** 2.1 */
DEFINE('_EW_MENU_DOWNLOADS', "Downloads");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_FILE_NOT_FOUND', "FILE NOT FOUND");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_HTACCESS_NOT_WRITABLE', "Your .htaccess is not Writable.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_HTACCESS_COULD_NOT_BE_CREATED', ".htaccess could not be created, Please create your own.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_ADD_EXTENSION', "Add Extension");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_EXTENSION_NAME', "Extension Name");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_WARNING', "<b>Warning:</b> always backup your .htaccess file before adding new extension or path! Do not add 'php' as monitored extension. <br/>Be also careful with adding png/jpg, the download count will be increased once someone opens your page which contains images with this extension.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_ADD_FILE_PATH', "Add File/Path");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_FILE_PATH_NAME', "File/Path Name");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_DOWNLOAD_MONITOR', "Download Monitor");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_EXTENSIONS_BEING_MONITORED', "Extensions Being Monitored");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_FILES_PATHS_BEING_MONITORED', "Files/Paths Being Monitored");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_EDIT_EXTENSION', "Edit Extension");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_EDIT_FILE_PATH', "Edit File/Path");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_EXTENSION', "Extension");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_ACTION', "Action");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_PATH', "Path");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_TODAY', "Today");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_YESTERDAY', "Yesterday");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_THIS_WEEK', "This Week");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_LAST_WEEK', "Last Week");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_THIS_MONTH', "This Month");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_LAST_MONTH', "Last Month");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_INCOMPLETE', "The required Information is incomplete");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_STATS_SOCIAL_MEDIA', "Media");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_AVAILABLE_IN_PRO',"Available in PRO version");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_TOTAL',"Total Downloads");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


/** 3.0 - hosted version */  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOALS_CLICKED_ELEMENT_XPATH_CONDITION', "xpath of clicked element condition");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_CLICKED_ELEMENT_XPATH_CONDITION', "xpath of clicked element condition");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_STATS_DEVICES', "Mobile Devices");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_BLOCKED_BASED_ON_GOAL',"Blocked based on goal no. %s");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  


DEFINE('_EW_TIME_BETWEEN_VISITS',"Total time spent");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_LEFT_WEBSITE',"Left website");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MENU_USERS',"Users");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_USERS_BLOCK_IP_CONFIRM',"Do you really want to block this IP address?");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_USERS_SHARING_HEADER',"Users sharing same login");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_USERS_SHARING_DESC',"Contains users who accessed the website from different IP addresses and/or from different country but with same login. This might be a warning for you, that they're sharing their account with someone else.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_USERS_ACTIVITY_HEADER',"Latest user activity");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
define('_EW_DESC_SEO_LIST_ENCRYPTED_KEYWORDS', "Google hides passing particular keywords from google search to websites. This will reveal the keyword's position,<br/> but not the keyword itself. Enable this option if you want to see also position of these encrypted keywords in stats.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_SEO_MOST_POPULAR_KEYPHRASES',"Most popular keyphrases");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_SEO_MOST_POPULAR_KEYPHRASES_DESC',"These are the keyphrases by which was your website found. You can copy this list and use it with some 3rd party service, which will give you an overview of SERP (Search Engine Rank Position). You can then optimize your website using SEO techniques,	and watch the increase of traffic in right upper side of main dashboard - displayed as a cyan bar");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_USERS_ALERT_EMAIL_SUBJECT',"Alert - user '%s' uses different IP address: '%s'");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_USERS_ALERT_EMAIL_CONTENT',"You can block this user from ExtraWatch Users section");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_MAX_RECORDS',"Displaying max. %d records");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_DESC_USERS_SEND_ALERT_EMAILS',"If checked, you'll get an email once user uses different IP. This can help you to detect immediately, which user shares his login with someone else. Useful, if you're using paid accounts.");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_SEO_SHOW_ALL_TIME_REPORT', "Do not filter by particular dates, show all time SEO report");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_DOWNLOADS_ALLOW_ONLY_REFERRER', "Allow only when referred from: ");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_ALLOWED_REFERRER', "Allowed Referrer");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_NOT_ALLOWED',"File download restricted by ExtraWatch rule. Please contact: %s");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_DOWNLOADS_EMAIL_RESTRICTED_SUBJECT',"Download restricted for IP: %s");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_EMAIL_RESTRICTED_BODY',"Someone from IP: %s attempted to download file: %s referred from %s, but it's restricted by ExtraWatch download referrer check");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_ADMINHEADER_CLICK_AREAS', "Click Areas");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_NO_TITLE','No Title');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_CLICK_HEATMAP_FOR','Click Heatmap for ');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_CLICK_AREAS_FOR','Clicks Areas for ');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_GOALS_SEND_EMAIL','Send an email');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DESC_GOALS_SEND_EMAIL','You will get an email everytime the goal has been reached. Email address is taken from "Emails" section.');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_GOAL_EMAIL_SUBJECT', "Goal '%s' was achieved, count: %d");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISITS_GOAL_REACHED', " Goal '%s' was reached");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  

DEFINE('_EW_DOWNLOADS_TOTAL_WEEKLY', "Total weekly");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ACTIVE', "active");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOAD_PRO', "Download PRO version");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_VISITS_HEATMAP_CLICK_COUNT', "Total clicks today: %d");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_HEATMAP_LOADING','Loading Heatmap table ...');  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ANTISPAM_INVALID_EXTENSION', "Invalid extension type, .csv expected");   	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_ANTISPAM_NUM_IP_FROM_CSV_IMPORTED', "Imported %d IP addresses from .csv file"); DEFINE('_EW_MENU_AVAILABLE_IN_PRO_HEATMAP', "With our most accurate Heat Map, you can monitor user clicks and see the hottest click areas of your web and optimize the content accordingly");
DEFINE('_EW_MENU_AVAILABLE_IN_PRO_CLICK_AREAS', "With Click Areas monitoring you can track clicks on buttons, links and improve the click rate");
DEFINE('_EW_MENU_AVAILABLE_IN_PRO_SEO_REPORT', "Position of your web links on search engines");
DEFINE('_EW_MENU_AVAILABLE_IN_PRO_USERS', "User Activity monitoring");
DEFINE('_EW_MENU_AVAILABLE_IN_PRO_FLOW', "Interactive chart with internal traffic distribution");
DEFINE('_EW_MENU_AVAILABLE_IN_PRO_DOWNLOADS', "See charts of downloads of zip, pdf or other downloadable artifacts");
DEFINE('_EW_MENU_AVAILABLE_IN_PRO_STATUS', "Database table sizes monitoring");
DEFINE('_EW_MENU_AVAILABLE_IN_PRO_COMPONENTS', "Directories size monitoring");
DEFINE('_EW_ADMINHEADER_SEARCH_RANK', "Search Rank");   	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_DOWNLOADS_START_ADD_EXT', "No download statistics currently recorded. Start monitoring file downloads and");  	 	    	    		  	 	  	 	  		 	 		    	 			 	   		  	 	 		 	 	   	      	  	 		 		 				 			 		  		    	 		 		  
DEFINE('_EW_NAVIGATION_VISITORS', 'Current Visitors');
DEFINE('_EW_NAVIGATION_LOCATION', 'Location');
DEFINE('_EW_NAVIGATION_BLOCKING', 'Blocking');
DEFINE('_EW_NAVIGATION_CLICKS', 'Clicks');
DEFINE('_EW_NAVIGATION_STATISTICS', 'Statistics');

DEFINE('_EW_MENU_AVAILABLE_IN_PRO_LOCATION', 'Location on a map');

DEFINE('_EW_BADGE_VISITORS',"Number of unique visitors for current day");
DEFINE('_EW_BADGE_HEATMAP',"Number of heatmap clicks for current day");
DEFINE('_EW_BADGE_LOCATION',"Number of countries from which was your website visited today");
DEFINE('_EW_BADGE_CLICKS',"Number of clicks on elements for current day");
DEFINE('_EW_BADGE_USERS',"Number of registered users today");
DEFINE('_EW_BADGE_SEO',"Number of keywords by which was your website found for today");
DEFINE('_EW_BADGE_DOWNLOAD',"Number of downloads of files for today");
DEFINE('_EW_BADGE_STATS',"Number of unique visits today");
DEFINE('_EW_BADGE_ANTISPAM',"Number of blocked spam attempts");
DEFINE('_EW_AVAILABLE_IN_FULL_VERSION', 'This feature is available in full version only');
DEFINE('_EW_GET_FULL_VERSION',"Get the full version of ExtraWatch PRO");
DEFINE('_EW_LIVE_STATS_SESSION_TIME', 'Time difference since user first visited your website');
DEFINE('_EW_DOWNLOAD_MONITOR_HTACCESS_TXT', 'Warning - please change: htaccess.txt is present in your joomla root folder, please rename it to .htaccess first and make sure there is no htaccess.txt file anymore !');
DEFINE('_EW_AGENT_NOT_PUBLISHED',"Agent module which gathers data is not published on frontend! - How to fix it?<br/><br/>
<u>Joomla:</u><br/>
1. Go to Extensions -> Module Manager -> find Agent module<br/>
2. Change Position to some other value (choose some for which you already see some module in frontend - like 'footer'<br/>
3. Save and refresh extrawatch back-end dashboard again<br/><br/>

<u>Wordpress:</u><br/>
1. Go to Apperance -> Widgets<br/>
2. Drag and Drop ExtraWatch agent do placeholder on right to widget that it's already visible in frontend<br/>
");
DEFINE('_EW_USER_NO_LONGER_EXISTS',"<i>User with id %d no longer exists</i>");