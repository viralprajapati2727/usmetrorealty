<?php
/**
 * @file
 * ExtraWatch - A real-time ajax monitor and live stats
 * @package ExtraWatch
 * @version 2.3
 * @revision 2650
 * @license http://www.gnu.org/licenses/gpl-3.0.txt     GNU General Public License v3
 * @copyright (C) 2016 by CodeGravity.com - All rights reserved!
 * @website http://www.extrawatch.com
 */

defined('_JEXEC') or die;

/**
 * ExtraWatch plugin to check spam in authentication form
 */
class PlgAuthenticationExtraWatch extends JPlugin
{
    public function onUserAuthenticate($credentials, $options, &$response)
    {
        if (@$options['action'] != "core.login.admin") { //skip checking admin login form
            if (!defined("DS")) {
                define("DS", DIRECTORY_SEPARATOR);
            }

            require_once(realpath(dirname(__FILE__).DS."..".DS."..".DS."..".DS."components".DS."com_extrawatch".DS."includes.php"));

            $extraWatch = new ExtraWatchMain();
            $extraWatch->block->checkPostRequestForSpam(ExtraWatchHelper::requestGet());
            $extraWatch->block->checkPostRequestForSpam(ExtraWatchHelper::requestPost());
        }


    }
}
