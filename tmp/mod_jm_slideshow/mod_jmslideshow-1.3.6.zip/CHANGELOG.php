<?php
/**
 * CHANGELOG
 *
 * This is the changelog for JMSlideshow.<br>
 * <b>Please</b> be patient =;)
 *
 * @version    SVN $Id$
 * @package    JoomlaMan JMSlideshow
 * @subpackage Documentation
 * @author     Expert Team Joomla {@link http://joomlaman.com}
 * @author     Created on 24-Sep-2012
 */
//--No direct access to this changelog...
defined('_JEXEC') || die('=;)');
//--For phpDocumentor documentation we need to construct a function ;)
/**
 * CHANGELOG
 * {@source}
 */
function CHANGELOG() {
  /*
    _______________________________________________
    _______________________________________________
    This is the changelog for slideshowbootstrap
    Please be patient =;)
    _______________________________________________
    _______________________________________________
    Legend:
   * -> Security Fix
    # -> Bug Fix
    + -> Addition
    ^ -> Change
    - -> Removed
    ! -> Note
    ______________________________________________
    24-Sep-2012 Expert Team Joomla
    ! Startup
   */
}
//--This is the END