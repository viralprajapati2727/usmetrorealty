<?php
defined('_JEXEC') or die('Restricted access');
require(JPATH_COMPONENT_ADMINISTRATOR.DS.'views'.DS.'property'.DS.'tmpl'.DS.'noaccess.php');
?>