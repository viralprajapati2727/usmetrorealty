ALTER TABLE  `#__iproperty_settings` CHANGE  `adv_show_radius`  `adv_show_shapetools` TINYINT( 1 ) NOT NULL DEFAULT  '1';
