<?php
defined('_JEXEC') or die('Restricted access');
require(JPATH_COMPONENT_ADMINISTRATOR.'/views/property/tmpl/noaccess.php');
?>