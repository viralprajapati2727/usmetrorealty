ALTER IGNORE TABLE `#__iproperty_saved` CHANGE `search_string` `search_string` TEXT NOT NULL;
